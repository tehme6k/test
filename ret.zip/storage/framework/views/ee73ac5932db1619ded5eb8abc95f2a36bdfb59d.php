<?php $__env->startSection('top-card-header'); ?>
    <div class="d-flex justify-content-end">
        <div>
            <button type="button" class="btn btn-success mb-2 mr-3" onclick="handleAdd()">Add</button>
        </div>
        <div>
            <button type="button" class="btn btn-danger mb-2" onclick="handleAdd()">Remove</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-card-body'); ?>
    <div class="d-flex justify-content-between">
        <div>
            Total Adjustmets: <br>
            Last Adjustment:
        </div>
        <div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-card-header'); ?>
    Full Inventory List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-card-body'); ?>
    <?php if($products->count() > 0): ?>
        <table class="table">
            <thead>
            <th>Name</th>
            <th>Adjustments Count</th>
            <th>Projects Used In</th>
            <th>Total Inventory</th>
            <th></th>
            </thead>

            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-link btn-md">
                            <?php echo e($product->name); ?>

                        </a>

                    </td>

                    <td>
                        <?php echo e($product->inventories->count()); ?>

                    </td>

                    <td>0</td>

                    <td>
                        <?php if($product->inventories->sum('amount') > 0): ?>
                            <?php if($product->category->name === 'Powder'): ?>
                                <?php echo e($product->inventories->sum('amount')); ?> Kg
                            <?php else: ?>
                                <?php echo e($product->inventories->sum('amount')); ?> each
                            <?php endif; ?>
                        <?php else: ?>
                            <font color="red">
                                <?php if($product->category->name === 'Powder'): ?>
                                    <?php echo e($product->inventories->sum('amount')); ?> Kg
                                <?php else: ?>
                                    <?php echo e($product->inventories->sum('amount')); ?> each
                                <?php endif; ?>
                            </font>
                        <?php endif; ?>
                    </td>

                    <td>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($products->links()); ?>

    <?php else: ?>
        <h3 class="text-center">No inventory products at this time</h3>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>





<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>