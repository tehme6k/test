<?php $__env->startSection('top-card-header'); ?>
    <div class="d-flex justify-content-end">
        <button class="btn btn-success mb-2" type="button" onclick="handleAdd()">
            Add Project
        </button>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-card-body'); ?>
    <p>Projects: <strong><?php echo e($projects->count()); ?></strong></p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-card-header'); ?>
    All Projects
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-card-body'); ?>
    <?php if($projects->count() > 0): ?>
        <table class="table">
            <thead>
            <th>Name</th>
            <th>Flavor</th>
            <th>Type</th>
            <th>Country</th>
            <th>Mpr Versions</th>

            </thead>

            <tbody>
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="<?php echo e(route('projects.show', $project->id)); ?>" class="btn btn-link btn-md">
                            <?php echo e($project->name); ?>

                        </a>
                    </td>

                    <td>
                        <?php echo e($project->flavor); ?>

                    </td>

                    <td>
                        <?php echo e($project->type->name); ?>

                    </td>

                    <td>
                        <?php echo e($project->country->name); ?>

                    </td>

                    <td>
                        0
                    </td>


                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($projects->links()); ?>

    <?php else: ?>
        <h3 class="text-center">No products at this time</h3>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('projects.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addModalLabel">Add Product</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="name" id="name" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="flavor">Flavor</label>
                            <input type="text" name="flavor" id="flavor" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="country_id">Country</label>
                            <select name="country_id" id="country_id" class="form-control">
                                <option value="">---</option>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>">
                                        <?php echo e($country->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="category_id">Type</label>
                            <select name="type_id" id="type_id" class="form-control">
                                <option value="">---</option>
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type->id); ?>">
                                        <?php echo e($type->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add Product</button>
                    </div>
                </div>
            </div>
        </div>

    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>