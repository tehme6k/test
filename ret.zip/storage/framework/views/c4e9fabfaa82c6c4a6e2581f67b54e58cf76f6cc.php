
<?php if(auth()->guard()->check()): ?>
    <div class="container">

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>

            <?php if(session()->has('fail')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('fail')); ?>

                </div>
            <?php endif; ?>

        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session()->get('error')); ?>

            </div>
        <?php endif; ?>

        <div class="row">
            
            <div class="col-md-4">

                <ul class="list-group">

                    <?php if(auth()->user()->isAdmin()): ?>
                        <li class="list-group-item">
                            <a href="<?php echo e(route('users.index')); ?>">
                                Users
                            </a>
                        </li>
                    <?php endif; ?>

                    <li class="list-group-item">
                        <a href="<?php echo e(route('categories.index')); ?>">Categories</a>
                    </li>

                    <li class="list-group-item">
                        <a href="<?php echo e(route('products.index')); ?>">Products</a>
                    </li>

                        <li class="list-group-item">
                            <a href="<?php echo e(route('projects.index')); ?>">Projects</a>
                        </li>

                    <li class="list-group-item">
                        <a href="<?php echo e(route('inventories.index')); ?>">Inventory</a>
                    </li>

                    <li class="list-group-item">
                        <a href="<?php echo e(route('boxes.index')); ?>">Retention</a>
                    </li>

                </ul>

                <ul class="list-group mt-5">

                    <li class="list-group-item">
                        Trashed
                    </li>

                </ul>

            </div>
            
            <div class="col-md-8">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
<?php else: ?>
    <?php echo $__env->yieldContent('content'); ?>
<?php endif; ?>
<?php /* G:\laragon\www\ret\resources\views/partials/sidebar.blade.php */ ?>