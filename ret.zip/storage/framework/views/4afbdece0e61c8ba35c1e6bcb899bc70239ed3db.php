<?php $__env->startSection('jumbotron-header'); ?>
    <div class="d-flex justify-content-start">
        <div>
            <a href="<?php echo e(route('projects.show', $bpr->project_id)); ?>" class="btn btn-link ">Back to project</a>
        </div>
    </div>
    <?php echo e($bpr->mpr->project->name); ?> -
    <?php echo e($bpr->mpr->project->flavor); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('jumbotron-under-header'); ?>
    Lot: <strong>
        <?php echo e(substr($bpr->lot_number, 0, 4)); ?> -
        <?php echo e(substr($bpr->lot_number, 4, 2)); ?> -
        <?php echo e(substr($bpr->lot_number, 6, 3)); ?>

    </strong>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('jumbotron-content'); ?>
    <div class="d-flex justify-content-between">
        <div>
            <h3> By: <strong> <?php echo e($bpr->mpr->createdBy->name); ?></strong></h3>
            <h4> Batch size: <strong><?php echo e($bpr->bottle_count); ?> bottles</strong></h4>
            <h4>Theoretical Yield: <strong> <?php echo e($bpr->powders()->sum('amount')); ?> </strong></h4>
        </div>

        <div>
            <h3>Mpr Version # <strong><?php echo e($bpr->mpr->version); ?></strong></h3>
            <h4>Created <strong><?php echo e($bpr->created_at->diffForHumans()); ?></strong></h4>
            <h4>Grams Per Bottle: <strong>  <?php echo e($bpr->mpr->gpb); ?> </strong></h4>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('jumbotron-buttons'); ?>
    <?php if($bpr->status === 'approved'): ?>
        <h3>
            Issued by <strong><?php echo e($bpr->createdBy->name); ?></strong> <?php echo e($bpr->updated_at->diffForHumans()); ?>

        </h3>
    <?php elseif($bpr->status === 'rejected'): ?>
        <h3>
            Rejected by <strong><?php echo e($bpr->createdBy->name); ?></strong> <?php echo e($bpr->updated_at->diffForHumans()); ?>

        </h3>
        <h4>
            Reason: <strong><?php echo e($bpr->reason); ?></strong>
        </h4>
    <?php else: ?>
        <button type="button" class="btn btn-primary my-2 mr-2" onclick="handleApprove()">Issue Batch</button>
        <button type="button" class="btn btn-warning my-2" onclick="handleReject()">Reject Batch</button>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table-header'); ?>
    <th>Name</th>
    <th>Type</th>
    <th>Quantity</th>
    <th>UOM</th>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table-body'); ?>
    <?php $__currentLoopData = $bpr->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e($product->name); ?>

            </td>

            <td>
                <?php echo e($product->category->name); ?>

            </td>

            <td>
                <?php echo e($product->pivot->amount); ?>

            </td>

            <td>
                <?php if($product->category->name == 'Powder'): ?>
                    g
                <?php else: ?>
                    each
                <?php endif; ?>
            </td>

        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <form autocomplete="off" action="<?php echo e(route('bprs.approve', $bpr->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="modal fade" id="approveModal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="approveModalLabel">
                            <?php echo e($bpr->mpr->project->name); ?> -
                            <?php echo e($bpr->mpr->project->flavor); ?> : Issue Batch
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="text" class="form-control" name="email">
                        </div>

                        <div class="form-group">
                            <label for="email">Password</label>
                            <input type="password" class="form-control" name="password">
                        </div>




                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

    </form>

    <form autocomplete="new-password" action="<?php echo e(route('bprs.reject', $bpr->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div class="modal fade" id="rejectModal" tabindex="-1" role="dialog" aria-labelledby="rejectModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="approveModalLabel">
                            <?php echo e($bpr->mpr->project->name); ?> -
                            <?php echo e($bpr->mpr->project->flavor); ?> : Reject Batch
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="text" class="form-control" name="email">
                        </div>

                        <div class="form-group">
                            <label for="email">Password</label>
                            <input type="password" class="form-control" name="password">
                        </div>

                        <div class="form-group">
                            <label for="reason">Reason</label>
                            <input type="text" class="form-control" name="reason">
                            </label>
                        </div>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function handleApprove() {
            console.log('Opening Modal from inventories.show.blade.php file scripts section')

            $('#approveModal').modal('show')
        }

        function handleReject() {
            console.log('Opening Modal from inventories.show.blade.php file scripts section')

            $('#rejectModal').modal('show')
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>