<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between">

        <div>
            <a href="<?php echo e(URL::previous()); ?>" type="button" class="btn btn-primary mb-2 ">Back</a>
        </div>
        <div>
            <button type="button" class="btn btn-success mb-2 " onclick="handleAdd()">New</button>
        </div>

    </div>

    <div class="d-flex justify-content-between mb-2">
        <div>
            <h2><?php echo e($project->name); ?> -
                <?php echo e($project->flavor); ?></h2>
            By: <strong> <?php echo e($project->createdBy->name); ?></strong>


        </div>

        <div>

            Created <strong><?php echo e($project->created_at->diffForHumans()); ?></strong>
        </div>
    </div>

    <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card card-default">
        <div class="card-header">
            View MPR's
        </div>
        <div class="card-body">

            <?php if($mprs->count() > 0): ?>

                <table class="table">
                    <thead>
                    <th>Version</th>
                    <th>Serving Size</th>
                    <th>Created By</th>
                    <th>Status</th>
                    </thead>


                    <tbody>
                    <?php $__currentLoopData = $mprs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mpr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($mpr->version); ?>

                            </td>

                            <td>
                                <?php echo e($mpr->serving_size); ?>

                            </td>

                            <td>
                                <?php echo e($mpr->createdBy->name); ?>

                            </td>

                            <td>
                                <a href="<?php echo e(route('mprs.show', $mpr->id)); ?>" class="btn btn-link btn-md">
                                    <?php echo e($mpr->status); ?>

                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h3 class="text-center">No MPRs at this time</h3>
            <?php endif; ?>


        </div>
    </div>


    <div class="card card-default mt-2">
        <div class="card-header">
            Batch Issues
        </div>

        <div class="card-body">



            <?php if($bprs->count() > 0): ?>
                <table class="table">
                    <thead>
                    <th>Lot Number</th>
                    <th>Bottle Count</th>
                    <th>Created By</th>
                    <th>Status</th>
                    </thead>


                    <tbody>
                    <?php $__currentLoopData = $bprs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bpr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($bpr->lot_number); ?>

                            </td>

                            <td>
                                <?php echo e($bpr->bottle_count); ?>

                            </td>

                            <td>
                                <?php echo e($mpr->createdBy->name); ?>

                            </td>

                            <td>
                                <a href="<?php echo e(route('bprs.show', $bpr->id)); ?>" class="btn btn-link btn-md">
                                    <?php echo e($bpr->status); ?>

                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h3 class="text-center">No Batch Issues at this time</h3>
            <?php endif; ?>
        </div>
    </div>





    <form action="<?php echo e(route('mprs.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addModalLabel">Start next version for: <?php echo e($project->name); ?> - <?php echo e($project->flavor); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">

                        <input type="hidden" name="version" value="<?php echo e($mprs->count()); ?>">

                        <div class="form-group">
                            <label for="serving_size">Serving Size</label>
                            <input type="number" name="serving_size" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

    </form>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function handleStart() {
            console.log('Opening Modal from projects.show.blade.php file scripts section')

            $('#startModal').modal('show')
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\laragon\www\ret\resources\views/projects/show.blade.php */ ?>