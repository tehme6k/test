<?php $__env->startSection('content'); ?>


        <div class="d-flex justify-content-between">
                <div>
                        <a href="<?php echo e(URL::previous()); ?>" type="button" class="btn btn-primary mb-2 ">Back</a>
                </div>

                <div>
                        <?php if($mpr->status == 'approved'): ?>
                                <div class="d-flex justify-content-end">
                                        <button type="button" class="btn btn-success mb-2 " onclick="handleNewBPR()">Create BPR</button>
                                </div>
                        <?php else: ?>
                                <div class="d-flex justify-content-end">
                                        <button type="button" class="btn btn-success mb-2 " onclick="handleAdd()">Add Product</button>
                                </div>
                        <?php endif; ?>

                </div>
        </div>

        <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="d-flex justify-content-between mb-2">
                <div>
                        <h2><?php echo e($mpr->project->name); ?> -
                                <?php echo e($mpr->project->flavor); ?></h2>
                        By: <strong> <?php echo e($mpr->createdBy->name); ?></strong>


                </div>

                <div>
                        <h3>Version # <strong><?php echo e($mpr->version); ?></strong></h3>
                        Created <strong><?php echo e($mpr->created_at->diffForHumans()); ?></strong>
                </div>
        </div>

        <?php if($mpr->products->count() > 0): ?>

                <table class="table">
                        <thead>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Quantity</th>
                        <th>UOM</th>
                        </thead>

                        <tbody>
                        <?php $__currentLoopData = $mpr->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                        <td>
                                                <?php echo e($product->name); ?>

                                        </td>

                                        <td>
                                                <?php echo e($product->category->name); ?>

                                        </td>

                                        <td>
                                                <?php echo e($product->pivot->amount); ?>

                                        </td>

                                        <td>
                                                <?php if($product->category->name == 'Powder'): ?>
                                                        mg
                                                <?php else: ?>
                                                        each
                                                <?php endif; ?>
                                        </td>

                                </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                </table>

                <div class="d-flex justify-content-end">
                        <div>
                                <button type="button" class="btn btn-outline-primary mt-2" onclick="handleApprove()">Approve</button>
                        </div>
                </div>

        <?php else: ?>
                <h3 class="text-center">No products added yet.</h3>
        <?php endif; ?>



        <form action="<?php echo e(route('mpr.add')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                        <div class="modal-header">
                                                <h5 class="modal-title" id="addModalLabel">Add Product</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                </button>
                                        </div>
                                        <div class="modal-body">

                                                <input type="hidden" name="mpr_id" value="<?php echo e($mpr->id); ?>">

                                                <div class="form-group">
                                                        <label for="product_id">Select Product</label>
                                                        <select class="form-control" name="product_id" id="product_id">
                                                                <option value="">---</option>
                                                                <?php $__currentLoopData = $allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($allProduct->id); ?>"><?php echo e($allProduct->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                </div>

                                                <div class="form-group">
                                                        <label for="amount">Amount</label>
                                                        <input type="number" step="any" class="form-control" name="amount" id="amount">
                                                </div>
                                        </div>
                                        <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Save</button>
                                        </div>
                                </div>
                        </div>
                </div>

        </form>


        <form action="<?php echo e(route('bprs.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal fade" id="newBprModal" tabindex="-1" role="dialog" aria-labelledby="newBprModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                        <div class="modal-header">
                                                <h5 class="modal-title" id="newBprModalLabel">New BPR</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                </button>
                                        </div>
                                        <div class="modal-body">

                                                <input type="hidden" name="mpr_id" value="<?php echo e($mpr->id); ?>">
                                                <input type="hidden" name="serving_size" value="<?php echo e($mpr->serving_size); ?>">
                                                <input type="hidden" name="project_id" value="<?php echo e($mpr->project->id); ?>">



                                                <div class="form-group">
                                                        <label for="bottle_count">Bottle Count</label>
                                                        <input type="number" class="form-control" name="bottle_count" id="bottle_count">
                                                </div>
                                        </div>
                                        <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Save</button>
                                        </div>
                                </div>
                        </div>
                </div>

        </form>


        <form autocomplete="off" action="<?php echo e(route('mprs.approve', $mpr->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal fade" id="approveModal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                        <div class="modal-header">
                                                <h5 class="modal-title" id="approveModalLabel"><?php echo e($mpr->project->name); ?> - <?php echo e($mpr->project->flavor); ?> : Approve</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                </button>
                                        </div>
                                        <div class="modal-body">

                                                <div class="form-group">
                                                        <label for="email">Email Address</label>
                                                        <input type="text" class="form-control" name="email">
                                                </div>

                                                <div class="form-group">
                                                        <label for="email">Password</label>
                                                        <input type="password" class="form-control" name="password">
                                                </div>



                                        </div>
                                        <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Save</button>
                                        </div>
                                </div>
                        </div>
                </div>

        </form>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
        <script>
                function handleNewBPR() {
                        console.log('Opening Modal from mpr.show.blade.php file scripts section')

                        $('#newBprModal').modal('show')
                }

                function handleApprove() {
                        console.log('Opening Modal from mpr.show.blade.php file scripts section')

                        $('#approveModal').modal('show')
                }
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\laragon\www\ret\resources\views/mprs/show.blade.php */ ?>