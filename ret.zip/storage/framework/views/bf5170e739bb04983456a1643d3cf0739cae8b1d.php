<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card card-default mb-2">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <div>
                        <a href="<?php echo e(route('boxes.index')); ?>" class="btn btn-primary mb-2">
                            View Open Boxes
                        </a>
                    </div>

                    <div>
                        <button type="button" class="btn btn-success mb-2" onclick="handleAdd()">
                            Add Box
                        </button>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        Total Open: <strong><?php echo e($open_boxes_count->count()); ?></strong><br>
                        Total Reopened: <strong><?php echo e($reopen_boxes->count()); ?></strong>
                    </div>

                    <div>
                        Total Closed: <strong><?php echo e($closed_boxes_count->count()); ?></strong><br>
                        Total all: <strong><?php echo e($all_boxes->count()); ?></strong>
                    </div>
                </div>
            </div>
        </div>





            <div class="card card-default">
                <div class="card-header">
                    Closed Retention Boxes
                </div>

                <div class="card-body">
                    <?php if($boxes->count() > 0): ?>
                        <table class="table">
                            <thead>
                            <th>Box #</th>
                            <th>Hold Until</th>
                            <th>Opened On</th>
                            <th>Closed On</th>
                            <th>Opened by</th>
                            <th>Closed By</th>
                            <th></th>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $boxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $box): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($box->id); ?>

                                    </td>

                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($box->hold_date)->format('d M Y')); ?>


                                    </td>

                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($box->created_at)->format('d M Y')); ?>


                                    </td>

                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($box->closed_at)->format('d M Y')); ?>


                                    </td>

                                    <td>
                                        <?php echo e($box->openedBy->name); ?>

                                    </td>

                                    <td>
                                        <?php echo e($box->closedBy->name); ?>

                                    </td>


                                    <td>
                                        <a href="<?php echo e(route('boxes.show', $box->id)); ?>" class="btn btn-info btn-sm">Open</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($boxes->links()); ?>

                    <?php else: ?>
                        <h3 class="text-center">No boxes at this time</h3>
                    <?php endif; ?>



                </div>

            </div>

        <form action="<?php echo e(route('boxes.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addModalLabel">Add new box?</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">

                            <?php if($open_boxes_count->count() > 0): ?>
                                You have the boxes listed already open. Are you still sure you wish to start a new box?
                                <ul class="list-group">
                                    <?php $__currentLoopData = $open_boxes_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $open_box): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item">
                                            Box[<?php echo e($open_box->id); ?>]
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                You have no boxes currenly open. Click 'New Box' Below to start a new box.
                            <?php endif; ?>

                        </div>
                        <div class="modal-footer d-flex justify-content-between">
                            <div>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                            <div>
                                <button type="submit" class="btn btn-primary">New Box</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>