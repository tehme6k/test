<?php $__env->startSection('jumbotron-header'); ?>
    <div class="d-flex justify-content-start">
        <div>
            <a href="<?php echo e(route('products.show', $inventory->product->id)); ?>" class="btn btn-link">Back</a>
        </div>
    </div>
    <?php echo e($inventory->product->name); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('jumbotron-under-header'); ?>
    <?php echo e(number_format($inventory->amount, 2)); ?> <?php echo e($unit); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('jumbotron-content'); ?>
    <h4>Status <strong><?php echo e($inventory->status); ?></strong></h4>
    <h3>Created <strong><?php echo e($inventory->created_at->diffForHumans()); ?></strong></h3>
    <h3>By <strong><?php echo e($inventory->createdBy->name); ?></strong></h3>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('jumbotron-buttons'); ?>
    <?php if($inventory->status != 'approved'): ?>
        <button type="button" class="btn btn-success mb-2 " onclick="handleApprove()">Approve</button>
    <?php endif; ?>

    <?php if($inventory->status != 'rejected'): ?>
        <button type="button" class="btn btn-danger mb-2 ml-2" onclick="handleReject()">Reject</button>
    <?php endif; ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <form autocomplete="off" action="<?php echo e(route('inventories.approve', $inventory->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="modal fade" id="approveModal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="approveModalLabel"><?php echo e($inventory->product->name); ?> : Approve</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="text" class="form-control" name="email">
                        </div>

                        <div class="form-group">
                            <label for="email">Password</label>
                            <input type="password" class="form-control" name="password">
                        </div>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

    </form>

    <form autocomplete="new-password" action="<?php echo e(route('inventories.reject', $inventory->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div class="modal fade" id="rejectModal" tabindex="-1" role="dialog" aria-labelledby="rejectModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="rejectModalLabel"><?php echo e($inventory->product->name); ?> : Reject</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="text" class="form-control" name="email">
                        </div>

                        <div class="form-group">
                            <label for="email">Password</label>
                            <input type="password" class="form-control" name="password">
                        </div>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

    </form>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        function handleApprove() {
            console.log('Opening Modal from inventories.show.blade.php file scripts section')

            $('#approveModal').modal('show')
        }

        function handleReject() {
            console.log('Opening Modal from inventories.show.blade.php file scripts section')

            $('#rejectModal').modal('show')
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>