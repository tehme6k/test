<?php $__env->startSection('content'); ?>

    <div class="d-flex justify-content-between mb-2">
        <div>
            <a href="<?php echo e(route('boxes.index')); ?>" class="btn btn-primary">
                Back
            </a>
        </div>

        <div>
            <button type="button" class="btn btn-outline-danger" onclick="handleClose()">
                Close this box
            </button>
        </div>
    </div>


    <div class="card card-default mb-4">
        <div class="card-header">
            Info for reopen of Box #: <?php echo e($box->id); ?>

        </div>

        <div class="card-body">
            Requested By: <strong><?php echo e($reopendata->requestedBy->name); ?></strong><br>
            On: <strong><?php echo e(\Carbon\Carbon::parse($reopendata->reopen_date)->format('d M Y')); ?></strong><br>
            Reason: <strong><?php echo e($reopendata->reason); ?></strong>

        </div>
    </div>


    <div class="card card-default">
        <div class="card-header">Reopened Retention Box # <?php echo e($box->id); ?></div>
        <div class="card-body">

            <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('partials.retention_bottles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        </div>
    </div>







    <form action="<?php echo e(route('reopen.close', [$box->id, $reopendata->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="modal fade" id="closeModal" tabindex="-1" role="dialog" aria-labelledby="closeModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="closeModalLabel">Close Box</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="close_date" value="<?php echo e($reopendata->reopen_date); ?>">
                        <input type="hidden" name="closed_by" value="<?php echo e(auth()->user()->id); ?>">

                        Click 'Close Box' below if you are sure you wish to close this box and store it.

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Close Box</button>
                    </div>
                </div>
            </div>
        </div>
    </form>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    <script>




        function handleClose() {
            console.log('Opening Modal from reopens.blade.php script section')

            $('#closeModal').modal('show')
        }

        flatpickr('#production_date', {
        })

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\laragon\www\ret\resources\views/boxes/reopens.blade.php */ ?>