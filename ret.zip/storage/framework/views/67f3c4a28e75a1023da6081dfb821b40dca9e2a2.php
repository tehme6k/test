<?php $__env->startSection('content'); ?>


    <div class="d-flex justify-content-between">
        <div>
            <a href="<?php echo e(URL::previous()); ?>" type="button" class="btn btn-primary mb-2 ">Back</a>
        </div>

        <div>

        </div>
    </div>


    <div class="d-flex justify-content-between mb-2">
        <div>
            <h2><?php echo e($bpr->mpr->project->name); ?> -
                <?php echo e($bpr->mpr->project->flavor); ?></h2>
            By: <strong> <?php echo e($bpr->mpr->createdBy->name); ?></strong>


        </div>

        <div>
            <h3>Mpr Version # <strong><?php echo e($bpr->mpr->version); ?></strong></h3>
            Created <strong><?php echo e($bpr->created_at->diffForHumans()); ?></strong>
        </div>
    </div>



        <table class="table">
            <thead>
            <th>Name</th>
            <th>Type</th>
            <th>Quantity</th>
            <th>UOM</th>
            </thead>

            <tbody>
            <?php $__currentLoopData = $bpr->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($product->name); ?>

                    </td>

                    <td>
                        <?php echo e($product->category->name); ?>

                    </td>

                    <td>
                        <?php echo e($product->pivot->amount); ?>

                    </td>

                    <td>
                        <?php if($product->category->name == 'Powder'): ?>
                            g
                        <?php else: ?>
                            each
                        <?php endif; ?>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>








<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\laragon\www\ret\resources\views/bprs/show.blade.php */ ?>