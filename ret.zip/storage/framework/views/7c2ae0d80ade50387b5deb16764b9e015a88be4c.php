
<?php echo $__env->make('layouts.test2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>