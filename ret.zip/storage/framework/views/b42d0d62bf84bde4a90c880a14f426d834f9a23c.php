<section class="jumbotron text-center">
    <div class="container">
        <h1 class="jumbotron-heading">
            <?php echo $__env->yieldContent('jumbotron-header'); ?>
        </h1>
        <h2>
            <?php echo $__env->yieldContent('jumbotron-below-header'); ?>
        </h2>

        <p class="lead text-muted">
            <?php echo $__env->yieldContent('jumbotron-body'); ?>
        </p>

        <p>
            <?php echo $__env->yieldContent('jumbotron-buttons'); ?>
        </p>
    </div>
</section>

