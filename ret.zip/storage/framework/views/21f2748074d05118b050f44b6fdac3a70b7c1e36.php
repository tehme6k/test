<?php $__env->startSection('jumbotron-header'); ?>
    <?php echo e($product->name); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('jumbotron-under-header'); ?>
    <?php echo e($product->category->name); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('jumbotron-content'); ?>
    <h3> By: <strong> <?php echo e($product->user->name); ?></strong></h3>
    <?php if(isset($total)): ?>
        <h4>Total: <?php echo e(number_format($total->sum('amount'), 2)); ?> <?php echo e($unit); ?></h4>
    <?php else: ?>
        <h4>Total: 0</h4>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('jumbotron-buttons'); ?>
    <div>
        <button type="button" class="btn btn-success mb-2 " onclick="handleAdd()">Add</button>
        <?php if($total->sum('amount') > 0): ?>
            <button type="button" class="btn btn-danger mb-2 ml-2" onclick="handleRemove()">Remove</button>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('table-header'); ?>
    <th>Amount</th>
    <th>Added By</th>
    <th>Added On</th>
    <th>Status</th>
<?php $__env->stopSection(); ?>


<?php if($inventories->count() > 0): ?>
    <?php $__env->startSection('table-body'); ?>
        <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href="<?php echo e(route('inventories.show', $inventory->id)); ?>" class="btn btn-link">
                        <?php echo e(number_format($inventory->amount, 2)); ?> <?php echo e($unit); ?>

                    </a>
                </td>

                <td>
                    <?php echo e($inventory->createdBy->name); ?>

                </td>

                <td>
                    <?php echo e($inventory->created_at); ?>

                </td>

                <td>
                    <?php echo e($inventory->status); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
<?php else: ?>
    <?php $__env->startSection('table-body'); ?>
        <tr>
            <td colspan="4">
                Nothing to show.
            </td>
        </tr>
    <?php $__env->stopSection(); ?>
<?php endif; ?>


<?php $__env->startSection('content'); ?>
    <form action="<?php echo e($unit == 'Kg' ?  route('inventories.powder.store')  :  route('inventories.nonpowder.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addModalLabel"><?php echo e($product->name); ?> : Add</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <input type="hidden" name="product_id" id="product_name" value="<?php echo e($product->id); ?>">
                        <input type="hidden" name="adjustment_method" id="adjustment_method" value="add">


                        <div class="form-group">
                            <label for="amount">Amount</label>
                            <input type="number" name="amount" id="amount" class="form-control">
                        </div>

                        <?php if($unit == 'Kg'): ?>
                            <div class="form-group">
                                <label for="unit">Unit</label>
                                <select name="unit" id="unit" class="form-control">
                                    <option value="">---</option>
                                    <option value="g">grams</option>
                                    <option value="kg">kilograms</option>
                                    <option value="lb">pounds</option>
                                </select>
                            </div>
                        <?php endif; ?>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

    </form>

    <form action="<?php echo e($unit == 'Kg' ?  route('inventories.powder.store')  :  route('inventories.nonpowder.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="removeModal" tabindex="-1" role="dialog" aria-labelledby="removeModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="removeModalLabel"><?php echo e($product->name); ?> : Remove</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <input type="hidden" name="product_id" id="product_name" value="<?php echo e($product->id); ?>">
                        <input type="hidden" name="adjustment_method" id="adjustment_method" value="remove">



                        <div class="form-group">
                            <label for="amount">Amount</label>
                            <input type="number" name="amount" id="amount" class="form-control">
                        </div>

                        <?php if($unit == 'Kg'): ?>
                            <div class="form-group">
                                <label for="unit">Unit</label>
                                <select name="unit" id="unit" class="form-control">
                                    <option value="">---</option>
                                    <option value="g">grams</option>
                                    <option value="kg">kilograms</option>
                                    <option value="lb">pounds</option>
                                </select>
                            </div>
                        <?php endif; ?>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        function handleRemove() {
            console.log('Opening Modal from products.show.blade.php file scripts section')

            $('#removeModal').modal('show')
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>