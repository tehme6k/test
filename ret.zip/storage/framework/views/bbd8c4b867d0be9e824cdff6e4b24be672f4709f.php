<?php $__env->startSection('jumbotron-header'); ?>
    <div class="d-flex justify-content-start">
        <div>
            <a href="<?php echo e(route('boxes.index')); ?>" class="btn btn-link">View All Open Boxes</a>
        </div>
    </div>

    Retention Box # <strong><?php echo e($box->id); ?></strong>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('jumbotron-under-header'); ?>
     <strong><?php echo e($box->status); ?> -
    <?php echo e($retentions->count()); ?></strong> total products</h3>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('jumbotron-content'); ?>
    <h3>Requested By: <strong><?php echo e($reopendata->requestedBy->name); ?></strong><br></h3>
    <h3>On: <strong><?php echo e(\Carbon\Carbon::parse($reopendata->reopen_date)->format('d M Y')); ?></strong><br></h3>
    <h3>Reason: <strong><?php echo e($reopendata->reason); ?></strong></h3>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('jumbotron-buttons'); ?>
    <button type="button" class="btn btn-outline-danger" onclick="handleClose()">
        Close this box
    </button>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('table-header'); ?>
    <th>Lot #</th>
    <th>Name</th>
    <th>Production</th>
    <th>Expiration</th>
    <th>Added By</th>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('table-body'); ?>
    <?php $__currentLoopData = $retentions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retention): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e(substr($retention->lot_number, 0, 4)); ?> -
                <?php echo e(substr($retention->lot_number, 4, 2)); ?> -
                <?php echo e(substr($retention->lot_number, 6, 3)); ?>

            </td>

            <td>
                <?php echo e($retention->project->name); ?> -
                <?php echo e($retention->project->flavor); ?>

            </td>

            <td>
                <?php echo e(\Carbon\Carbon::parse($retention->production_date)->format('d M Y')); ?>

            </td>

            <td>
                <?php echo e(\Carbon\Carbon::parse($retention->expiration_date)->format('d M Y')); ?>

            </td>

            <td>
                <?php echo e($retention->user->name); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('reopen.close', [$box->id, $reopendata->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="modal fade" id="closeModal" tabindex="-1" role="dialog" aria-labelledby="closeModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="closeModalLabel">Close Box</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="close_date" value="<?php echo e($reopendata->reopen_date); ?>">
                        <input type="hidden" name="closed_by" value="<?php echo e(auth()->user()->id); ?>">

                        Click 'Close Box' below if you are sure you wish to close this box and store it.

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Close Box</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    <script>




        function handleClose() {
            console.log('Opening Modal from reopens.blade.php script section')

            $('#closeModal').modal('show')
        }

        flatpickr('#production_date', {
        })

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>