<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($product->name); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>