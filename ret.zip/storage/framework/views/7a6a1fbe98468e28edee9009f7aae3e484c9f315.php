<?php $__env->startSection('top-card-header'); ?>
    <div class="d-flex justify-content-end">
        <button type="button" class="btn btn-primary my-2" onclick="handleAdd()">
            Add User
        </button>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-card-body'); ?>
    <p>Users: <strong><?php echo e($users->count()); ?></strong></p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-card-header'); ?>
    All Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-card-body'); ?>
    <?php if($users->count() > 0): ?>
        <table class="table">
            <thead>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>When</th>
            <th>Created By</th>
            <th></th>
            </thead>

            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($user->name); ?>

                    </td>

                    <td>
                        <?php echo e($user->email); ?>

                    </td>

                    <td>
                        <?php echo e($user->role); ?>

                    </td>

                    <td>
                        <?php echo e($user->created_at->diffForHumans()); ?>

                    </td>

                    <td>
                        <?php if($user->created_by == 0): ?>
                            <?php echo e($user->name); ?>

                        <?php else: ?>
                            <?php echo e($user->createdBy->name); ?>

                        <?php endif; ?>
                    </td>

                    <td>
                        <a href="#" class="btn btn-info btn-sm">
                            View
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <h3 class="text-center">No users at this time</h3>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('users.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addModalLabel">Add new user</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="name" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" name="email" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="password">Password</label>
                            <input id="password" type="password" class="form-control" name="password" required>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm">Confirm Password</label>
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                        </div>

                        <div class="form-group">
                            <label for="role">Role</label>
                            <select name="role" id="role" class="form-control">
                                <option value="">---</option>
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                            </select>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add User</button>
                    </div>
                </div>
            </div>
        </div>

    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>