<?php $__env->startSection('first-card-header'); ?>
    <div class="d-flex justify-content-between">
        <div>
            <a href="<?php echo e(route('projects.index')); ?>" type="button" class="btn btn-primary mb-2 ">Back to all projects</a>
        </div>

        <div>
            <button type="button" class="btn btn-success mb-2 " onclick="handleAdd()">New Version</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('first-card-body'); ?>
    <h2><?php echo e($project->name); ?> -
        <?php echo e($project->flavor); ?>

    </h2>
    <h5>
        By <strong><?php echo e($project->createdBy->name); ?></strong> -
        <?php echo e($project->created_at->diffForHumans()); ?>

    </h5>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('second-card-header'); ?>
    All MPR Versions
<?php $__env->stopSection(); ?>


<?php $__env->startSection('second-card-body'); ?>
    <?php if($mprs->count() > 0): ?>
        <table class="table">
            <thead>
            <th>Version</th>
            <th>Serving Size</th>
            <th>Created By</th>
            <th>Status</th>
            </thead>


            <tbody>
            <?php $__currentLoopData = $mprs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mpr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($mpr->version); ?>

                    </td>

                    <td>
                        <?php echo e($mpr->serving_size); ?>

                    </td>

                    <td>
                        <?php echo e($mpr->createdBy->name); ?>

                    </td>

                    <td>
                        <a href="<?php echo e(route('mprs.show', $mpr->id)); ?>" class="btn btn-link btn-md">
                            <?php echo e($mpr->status); ?>

                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <h3 class="text-center">No MPRs at this time</h3>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('third-card-header'); ?>
    Batch Issues
<?php $__env->stopSection(); ?>


<?php $__env->startSection('third-card-body'); ?>
    <?php if($bprs->count() > 0): ?>
        <table class="table">
            <thead>
            <th>Lot Number</th>
            <th>Bottle Count</th>
            <th>Created By</th>
            <th>Status</th>
            </thead>


            <tbody>
            <?php $__currentLoopData = $bprs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bpr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($bpr->lot_number); ?>

                    </td>

                    <td>
                        <?php echo e($bpr->bottle_count); ?>

                    </td>

                    <td>
                        <?php echo e($mpr->createdBy->name); ?>

                    </td>

                    <td>
                        <a href="<?php echo e(route('bprs.show', $bpr->id)); ?>" class="btn btn-link btn-md">
                            <?php echo e($bpr->status == 'approved' ? 'Issued' : $bpr->status); ?>

                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <h3 class="text-center">No Batch Issues at this time</h3>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('mprs.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addModalLabel">Start next version for: <?php echo e($project->name); ?> - <?php echo e($project->flavor); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">

                        <input type="hidden" name="version" value="<?php echo e($mprs->count()); ?>">

                        <div class="form-group">
                            <label for="serving_size">Serving Size</label>
                            <input type="number" name="serving_size" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        function handleStart() {
            console.log('Opening Modal from projects.show.blade.php file scripts section')

            $('#startModal').modal('show')
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.projects', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>