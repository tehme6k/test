<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between">

        <div>
            <a href="<?php echo e(URL::previous()); ?>" type="button" class="btn btn-primary mb-2 ">Back</a>
        </div>

        <div>
            <button type="button" class="btn btn-success mb-2 " onclick="handleAdd()">Add</button>
            <?php if($total->sum('amount') > 0): ?>
                <button type="button" class="btn btn-danger mb-2 ml-2" onclick="handleRemove()">Remove</button>
            <?php endif; ?>
        </div>

    </div>

    <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card card-default">
        <div class="card-header d-flex justify-content-between">
            <div>
                <?php echo e($product->name); ?>

            </div>

            <div>
               <?php if(isset($total)): ?>
                    Total: <?php echo e(number_format($total->sum('amount'), 2)); ?> <?php echo e($unit); ?>

               <?php else: ?>
                   Total: 0
               <?php endif; ?>
            </div>
        </div>
        <div class="card-body">
            <?php if($inventories->count() > 0): ?>

                <table class="table">
                    <thead>
                    <th>Amount</th>
                    <th>Added By</th>
                    <th>Added On</th>
                    <th>Status</th>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('inventories.show', $inventory->id)); ?>" class="btn btn-link btn-sm">
                                    <?php echo e(number_format($inventory->amount, 2)); ?> <?php echo e($unit); ?>

                                </a>
                            </td>

                            <td>
                                <?php echo e($inventory->createdBy->name); ?>

                            </td>

                            <td>
                                <?php echo e($inventory->created_at); ?>

                            </td>

                            <td>
                                <?php echo e($inventory->status); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <h3 class="text-center">No inventory at this time</h3>
            <?php endif; ?>

        </div>
    </div>

    <form action="<?php echo e($unit == 'Kg' ?  route('inventories.powder.store')  :  route('inventories.nonpowder.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addModalLabel"><?php echo e($product->name); ?> : Add</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <input type="hidden" name="product_id" id="product_name" value="<?php echo e($product->id); ?>">
                        <input type="hidden" name="adjustment_method" id="adjustment_method" value="add">


                        <div class="form-group">
                            <label for="amount">Amount</label>
                            <input type="number" name="amount" id="amount" class="form-control">
                        </div>

                        <?php if($unit == 'Kg'): ?>
                            <div class="form-group">
                                <label for="unit">Unit</label>
                                <select name="unit" id="unit" class="form-control">
                                    <option value="">---</option>
                                    <option value="g">grams</option>
                                    <option value="kg">kilograms</option>
                                    <option value="lb">pounds</option>
                                </select>
                            </div>
                        <?php endif; ?>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

    </form>

    <form action="<?php echo e($unit == 'Kg' ?  route('inventories.powder.store')  :  route('inventories.nonpowder.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="removeModal" tabindex="-1" role="dialog" aria-labelledby="removeModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="removeModalLabel"><?php echo e($product->name); ?> : Remove</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <input type="hidden" name="product_id" id="product_name" value="<?php echo e($product->id); ?>">
                        <input type="hidden" name="adjustment_method" id="adjustment_method" value="remove">



                        <div class="form-group">
                            <label for="amount">Amount</label>
                            <input type="number" name="amount" id="amount" class="form-control">
                        </div>

                        <?php if($unit == 'Kg'): ?>
                            <div class="form-group">
                                <label for="unit">Unit</label>
                                <select name="unit" id="unit" class="form-control">
                                    <option value="">---</option>
                                    <option value="g">grams</option>
                                    <option value="kg">kilograms</option>
                                    <option value="lb">pounds</option>
                                </select>
                            </div>
                        <?php endif; ?>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

    </form>





<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function handleRemove() {
            console.log('Opening Modal from products.show.blade.php file scripts section')

            $('#removeModal').modal('show')
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\laragon\www\ret\resources\views/products/show.blade.php */ ?>