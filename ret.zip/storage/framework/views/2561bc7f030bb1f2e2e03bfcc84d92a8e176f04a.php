<?php $__env->startSection('top-card-header'); ?>
    <div class="d-flex justify-content-between">
        <div>
            <a href="<?php echo e(route('ret.closed')); ?>" class="btn btn-primary mb-2">
                View Closed Boxes
            </a>
        </div>

        <div>
            <button type="button" class="btn btn-success mb-2" onclick="handleAdd()">
                Add Box
            </button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-card-body'); ?>
    <div class="d-flex justify-content-between">
        <div>
            Total Open: <strong><?php echo e($open_boxes_count->count()); ?></strong><br>
            Total Reopened: <strong><?php echo e($reopen_boxes->count()); ?></strong>
        </div>

        <div>
            Total Closed: <strong><?php echo e($closed_boxes->count()); ?></strong><br>
            Total all: <strong><?php echo e($all_boxes->count()); ?></strong>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-card-header'); ?>
    Open Retention Boxes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-card-body'); ?>
    <?php if($open_boxes_count->count() > 0): ?>
        <table class="table">
            <thead>
            <th>Box #</th>
            <th>Opened On</th>
            <th>Opened By</th>
            <th></th>
            </thead>

            <tbody>
            <?php $__currentLoopData = $open_boxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $open_box): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($open_box->id); ?>

                    </td>

                    <td>
                        <?php echo e(\Carbon\Carbon::parse($open_box->created_at)->format('d M Y')); ?>

                    </td>

                    <td>
                        <?php echo e($open_box->openedBy->name); ?>

                    </td>

                    <td>
                        <a href="<?php echo e(route('boxes.show', $open_box->id)); ?>" class="btn btn-info btn-sm">View Contents</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($open_boxes->links()); ?>

    <?php else: ?>
        <h3 class="text-center">No boxes at this time</h3>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($reopen_datas->count() > 0): ?>
        <div class="card bg-warning  my-2">
            <div class="card-header">
                Reopened Retention Boxes
            </div>

            <div class="card-body">
                <table class="table">
                    <thead>
                    <th>Box #</th>
                    <th>Reopened On</th>
                    <th>Requested By</th>
                    <th></th>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $reopen_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($data->box_id); ?>

                            </td>

                            <td>
                                <?php echo e(\Carbon\Carbon::parse($data->reopen_date)->format('d M Y')); ?>

                            </td>

                            <td>
                                <?php echo e($data->requestedBy->name); ?>

                            </td>

                            <td>
                                <a href="<?php echo e(route('reopen.show', [$data->box_id, $data->id])); ?>" class="btn btn-info btn-sm">View Contents</a>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
        <?php endif; ?>

        </div>

        <form action="<?php echo e(route('boxes.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addModalLabel">Add new box?</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">

                            <?php if($open_boxes_count->count() > 0): ?>
                                You have the boxes listed already open. Are you still sure you wish to start a new box?
                                <ul class="list-group">
                                    <?php $__currentLoopData = $open_boxes_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $open_box): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item">
                                            Box[<?php echo e($open_box->id); ?>]
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                You have no boxes currenly open. Click 'New Box' Below to start a new box.
                            <?php endif; ?>

                        </div>
                        <div class="modal-footer d-flex justify-content-between">
                            <div>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                            <div>
                                <button type="submit" class="btn btn-primary">New Box</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>














<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>