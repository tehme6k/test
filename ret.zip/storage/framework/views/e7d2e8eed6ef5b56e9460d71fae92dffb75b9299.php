<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-end">
        <button type="button" class="btn btn-success mb-2 " onclick="handleApprove()">Approve</button>

        <button type="button" class="btn btn-danger mb-2 ml-2" onclick="handleReject()">Reject</button>

    </div>
    <div class="card card-default">
        <div class="card-header d-flex justify-content-between">
            <div>
                <?php echo e($inventory->product->name); ?>

            </div>

            <div>
                <?php if(isset($total)): ?>
                    Total: <?php echo e(number_format($total->sum('amount'), 2)); ?>

                    <?php echo e($inventory->product->category->name == 'Powder' ? 'Kg' : 'each'); ?>

                <?php else: ?>
                    Total: 0
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body">
            <?php if($inventory->count() > 0): ?>


                <table class="table">
                    <thead>
                    <th>Amount</th>
                    <th>Added By</th>
                    <th>Added On</th>
                    <th>Status</th>
                    </thead>

                    <tbody>
                                            <tr>
                            <td>
                                <?php echo e(number_format($inventory->amount, 2)); ?> <?php echo e($unit); ?>

                            </td>

                            <td>
                                <?php echo e($inventory->createdBy->name); ?>

                            </td>

                            <td>
                                <?php echo e($inventory->created_at); ?>

                            </td>

                            <td>
                                <?php echo e($inventory->status); ?>

                            </td>
                        </tr>
                    </tbody>
                </table>


            <?php else: ?>
                <h3 class="text-center">No inventory at this time</h3>
            <?php endif; ?>

        </div>
    </div>

    <form autocomplete="off" action="<?php echo e(route('inventories.approve', $inventory->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="modal fade" id="approveModal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="approveModalLabel"><?php echo e($inventory->product->name); ?> : Approve</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="text" class="form-control" name="email">
                    </div>

                    <div class="form-group">
                        <label for="email">Password</label>
                        <input type="password" class="form-control" name="password">
                    </div>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

    </form>

    <form autocomplete="new-password" action="<?php echo e(route('inventories.reject', $inventory->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div class="modal fade" id="rejectModal" tabindex="-1" role="dialog" aria-labelledby="rejectModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="rejectModalLabel"><?php echo e($inventory->product->name); ?> : Reject</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="text" class="form-control" name="email">
                        </div>

                        <div class="form-group">
                            <label for="email">Password</label>
                            <input type="password" class="form-control" name="password">
                        </div>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

    </form>





<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function handleApprove() {
            console.log('Opening Modal from inventories.show.blade.php file scripts section')

            $('#approveModal').modal('show')
        }

        function handleReject() {
            console.log('Opening Modal from inventories.show.blade.php file scripts section')

            $('#rejectModal').modal('show')
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\laragon\www\ret\resources\views/inventory/show.blade.php */ ?>