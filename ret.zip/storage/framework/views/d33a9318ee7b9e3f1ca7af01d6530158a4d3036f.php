<?php if($retentions->count() > 0): ?>
    <table class="table">
        <thead>
        <th>Lot #</th>
        <th>Name</th>
        <th>Production</th>
        <th>Expiration</th>
        <th>Added By</th>
        </thead>

        <tbody>
        <?php $__currentLoopData = $retentions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retention): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e(substr($retention->lot_number, 0, 4)); ?> -
                    <?php echo e(substr($retention->lot_number, 4, 2)); ?> -
                    <?php echo e(substr($retention->lot_number, 6, 3)); ?>

                </td>

                <td>
                    <?php echo e($retention->product->name); ?>

                </td>

                <td>
                    <?php echo e(\Carbon\Carbon::parse($retention->production_date)->format('d M Y')); ?>

                </td>

                <td>
                    <?php echo e(\Carbon\Carbon::parse($retention->expiration_date)->format('d M Y')); ?>

                </td>

                <td>
                    <?php echo e($retention->user->name); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php else: ?>
    <h3 class="text-center">No bottles at this time</h3>
<?php endif; ?>
<?php /* G:\laragon\www\ret\resources\views/partials/retention_bottles.blade.php */ ?>