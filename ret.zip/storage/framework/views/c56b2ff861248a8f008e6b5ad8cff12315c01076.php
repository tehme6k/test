<?php $__env->startSection('content'); ?>


    <div class="card card-default">
        <div class="card-header">Inventory</div>
        <div class="card-body">
            <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if($products->count() > 0): ?>
                <table class="table">
                    <thead>
                    <th>Name</th>
                    <th>Adjustments Count</th>
                    <th>Projects Used In</th>
                    <th>Total Inventory</th>
                    <th></th>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-link btn-md">
                                    <?php echo e($product->name); ?>

                                </a>

                            </td>

                            <td>
                                <?php echo e($product->inventories->count()); ?>

                            </td>

                            <td>0</td>

                            <td>
                                <?php if($product->inventories->sum('amount') > 0): ?>
                                    <?php if($product->category->name === 'Powder'): ?>
                                        <?php echo e($product->inventories->sum('amount')); ?> Kg
                                    <?php else: ?>
                                        <?php echo e($product->inventories->sum('amount')); ?> each
                                    <?php endif; ?>
                                <?php else: ?>
                                 <font color="red">
                                     <?php if($product->category->name === 'Powder'): ?>
                                         <?php echo e($product->inventories->sum('amount')); ?> Kg
                                     <?php else: ?>
                                         <?php echo e($product->inventories->sum('amount')); ?> each
                                     <?php endif; ?>
                                 </font>
                                <?php endif; ?>
                            </td>

                            <td>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($products->links()); ?>

            <?php else: ?>
                <h3 class="text-center">No inventory products at this time</h3>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function handleAddPowder() {
            console.log('Opening Modal from inventory.index.blade.php file scripts section')

            $('#addModalPowder').modal('show')
        }

        function handleAddNonPowder() {
            console.log('Opening Modal from inventory.index.blade.php file scripts section')

            $('#addModalNonPowder').modal('show')
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\laragon\www\ret\resources\views/inventory/index.blade.php */ ?>